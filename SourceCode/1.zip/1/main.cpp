#include "picture.h" //�����ͼͷ�ļ� 
#include<windows.h>
#define Q 37
void color(int a)
{
  SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE),a);
}
string name;
int ks;
char GAMEOVER;
int HP=100;       // Ѫ��
int ATK=10;       // ������
int DEF=10;       // ������
int FirstKey=0;   // 1��Կ��
int SecondKey=0;  // 2��Կ��
int ThirdKey=0;   // 3��Կ��
int Weapons=0;    // ����
int Armor=0;      // ����
int GOLD=0;       // ��Ǯ
int tf=-1;        // �츳
int bzcs=0;
int bz=0;
int si0=0;
int mmm=0;
int Wen1=0;
int zb=3;
int zd=0;
int jjj=0;
int jjjj=0;
int x=1,y=20;
int aHP=30;
int AHP=70;
int bHP=56;
int BHP=48;
int cHP=500;
int CHP=30;
int dHP=160;
int DHP=300;
int eHP=600;
int EHP=900;
int MHP=100000;
int aATK=15;
int AATK=22;
int bATK=24;
int BATK=181;
int cATK=25;
int CATK=999;
int dATK=97;
int DATK=666;
int eATK=999;
int EATK=1000;
int MATK=5000;
int aDEF=4;
int ADEF=8;
int bDEF=7;
int BDEF=0;
int cDEF=15;
int CDEF=0;
int dDEF=16;
int DDEF=50;
int eDEF=70;
int EDEF=100;
int MDEF=5000;
int aGOLD=1;
int AGOLD=3;
int bGOLD=2;
int BGOLD=5;
int cGOLD=6;
int CGOLD=8;
int dGOLD=8;
int DGOLD=100;
int eGOLD=100;
int EGOLD=300;
int MGOLD=10000;

char Map[Q][121]= {" _________________ ####################################################################################################",
                   "|                 |#    1   !  ?# +   + |CCC#       U        CC  !        +2b#]*! @@!             ?#?3?#     ����     #",
                   "|                 |##########   #   X   |aaa###################  ###########]#### ##################   #�������Ҽ��ƶ�#",
                   "|                 |#            # +   + #   ] # + # + # + # ] #  aaaa        @ #? #  1  +  1  =  ? #   # (&)��ʾ��--��#",
                   "|                 |#   ##################   # # #*# # #*# # # #  ###########!#  # #    ������Ŀ    #   # (b)����˵��#",
                   "|                 |#       112              # A # A # A # A # c  #       ab  ## # #   ѡ��������   #   # (z)��ʼ����Ϸ#",
                   "|                 |#   ############ ##############################@### #######  # ##################   # (a)ʹ���츳��#",
                   "|                 |#===#          # #              B      (    ]2#   # #?aaaa  ## c**2ת��������!!!#   #ע����Ӣ������#",
                   "|                 |#              # #ababababababab######C#A######   #+#?aaaa   # ##################   ################",
                   "|                 |#===############A#   c 212 c    #      #      #   ########## # #   A:2     <--- #ABC%  |*|*|*|*|*|*#",
                   "|                 |# ? C*]    (A+A2+#bababababababa#  ++  #  ++  #   B # C # c  # #   B:10    ���� #   #  #############",
                   "|                 |################## ############ #      #      # 2 # # # # # ## #   c:��    ѡ�� #   #  |]|]|]|]|]|]#",
                   "|                 |#   A       *                   #AA#########CC# * # # # # #  # ##################   #  #############",
                   "|                 |#   A       *                   %      )      # * # c # C ##   !d1              d   #  |+|+|+|+|+|+#",
                   "|                 |#   #############################!!!##############################################@#################",
                   "|                 |#          12       C          ?#                                                   #ħ������(С��)#",
                   "|_________________|############################## ################################################################### #",
                   "#                                              *]+ #33#aaa#aaa#aaa#aaa#aaa#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#",
                   "#%# ################################################ ##a#a#a#a#a#a#a#a#a#a#@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@#",
                   "#@#              C+*+*Cd?12#     #?3%3C%3C%3C%3C%3++1aaa#aaa#aaa#aaa#aaa#a%C++C++C++C++C++C++C++C++C++C++C++C++C++C++ #",
                   "#!######=####### ###########12321#################################################################################### #",
                   "#*a]+#*A d)+a**# #���߲���+#aaaaa#+####?#####?##************************###?#####?###12+*]aaaaaaaaaaaaaaaaaaa!CBAdcb# #",
                   "#a*b+#B* a!aa]]# #��������+#*****#?#EEEEE#EEEEE#]]]]]]]]]]]]]]]]]]]]]]]]#EEEEE#EEEEE#���ʦ��������������ŵ�ǽCBAdcba#",
                   "#]b*+#*C +(da++# #�ո�Ŷ+++#bbbbb#+#eeEee#eeEee#++++++++++++++++++++++++#eeEee#eeEee#12+*]aaaaaaaaaaaaaaaaaaa!CBAdcb#a#",
                   "################ #=-=?@+@dd#+++++#?#DeeeD#DeeeD#++++++++++++++++++++++++#DeeeD#DeeeD#################################a#",
                   "#                ########dd#ccccc#+#DDDDD#DDDDD#]]]]]]]]]]]]]]]]]]]]]]]]#DDDDD#DDDDD# �̵� #B*B+Ad% ?<--300����Կ��3#1#",
                   "#!aaaaaaaaaaaaaaa#         !]]]]]#?#DDDDD#DDDDD#************************#DDDDD#DDDDD########*B*A+A# ?<--200����Կ��2#2#",
                   "#                #ddddddddddd#####E###%#####%#############====#############%####%###?EEEEEE!B*B+A@# ?<--100����Կ��1#a#",
                   "#bbbbbbbbbbbbbbb!#################                                               |?M<--BOOS######!###################a#",
                   "#                #��������������?# ################################################?# 0000    0   0       0 0#������#a#",
                   "#@ccccccccccccccc#������,ѡA     # #��#                                             #      0  0 00   000000 0#?<----#C#",
                   "#                #��������,ѡB   # #��# ########################################### # 0 0   0 0    0  0   0 0    (  #C#",
                   "#ddddddddddddddd%#################?#��# #   #   #   #   #   #   #   #   #           # 0  0  0 0000  0 0 0 0 0 ##### #C#",
                   "#                #  ++A         ?# #->#?#?#   #   #   #   #   #   #   #   ###########  0  000       0   0 0   #?% # #1#",
                   "#!CCCCCCCCCCCCCC!# ############### ########################################?<-������#  000000000000000 00 0 0 #?@ # #2#",
                   "#++++++?C++++++++!  ++B         ?#    ] ] ] * * * + + + ] ] ] * * * + + +             0                 0   0 #?! C@!?#",
                   "#######################################################################################################################"
                  };
void tfsc()
{
  Cmd.HideCursor();
  if(tf==-1)
  {
    Seed();
    ifstream inf;
    ofstream outf;
    outf.open("D:\\mysterious_Palace\\game_archive\\system_tf.zsjm");
    outf<<rand()%5;
    outf.close();
    inf.open("D:\\mysterious_Palace\\game_archive\\system_tf.zsjm");
    inf>>tf;
    inf.close();
  }
  if(tf==0)
  {
    Cmd.Cout(0,11,"| �츳:����       |");
    Cmd.Cout(0,12,"| ����1ATK��1DEF  |");
    Cmd.Cout(0,13,"| ����10HP        |");
    Cmd.Cout(0,14,"| ATK>0����DEF>0  |");
    Cmd.Cout(0,15,"| ����ʹ��        |");
  }
  if(tf==1)
  {
    Cmd.Cout(0,11,"| �츳:�Ա�("+IntToString(zb)+"��)  |");
    Cmd.Cout(0,12,"| ��HP��Ϊ1,�ݻ�  |");
    Cmd.Cout(0,13,"| ������Ϊ���ĵ�  |");
    Cmd.Cout(0,14,"| 5*7����         |");
    Cmd.Cout(0,15,"| HP>=70����ʹ��  |");
  }
  if(tf==2)
  {
    Cmd.Cout(0,11,"| �츳:�ж�       |");
    Cmd.Cout(0,12,"| ���Ͱ�!������   |");
    Cmd.Cout(0,13,"| ϣ�����ܿ���Ŷ  |");
    Cmd.Cout(0,14,"| ��һ��,��һ��Ѫ |");
    Cmd.Cout(0,15,"|(ÿ��ʮ���о�ϲ!)|");
    GAMEOVER='2';
    zd++;
    if(zd%10==1)
    {
      ATK++;
      DEF++;
    }
    HP--;
  }
  if(tf==3)
  {
    Cmd.Cout(0,11,"| �츳:��         |");
    Cmd.Cout(0,12,"|                 |");
    Cmd.Cout(0,13,"|                 |");
    Cmd.Cout(0,14,"|                 |");
    Cmd.Cout(0,15,"|                 |");
  }
  if(tf==4)
  {
    Cmd.Cout(0,11,"| �츳:��         |");
    Cmd.Cout(0,12,"|                 |");
    Cmd.Cout(0,13,"|                 |");
    Cmd.Cout(0,14,"|                 |");
    Cmd.Cout(0,15,"|                 |");
  }
  if(tf==5)
  {
    Cmd.Cout(0,11,"| �츳:ս����   |");
    Cmd.Cout(0,12,"| ����:HP>5000    |");
    Cmd.Cout(0,13,"| [��Ȼ����]      |");
    Cmd.Cout(0,14,"| ATK+99999,DEF=0 |");
    Cmd.Cout(0,15,"| HP+5000         |");
  }
}
int tj,jj,sj;
int td,jd,sd;
int qt_tot=0;
string qt[101];
void jrwp(string a)
{
  qt[++qt_tot]=a;
}
void jz(string b)
{
  if(b=="����")
    tj++;
  if(b=="��")
    jj++;
  if(b=="ʥ��")
    sj++;
  if(b=="����")
    td++;
  if(b=="���")
    jd++;
  if(b=="ʥ��")
    sd++;
}
void wupin()
{
  Cmd.Cout(0,0, "------------------------------------------------------------------------------------------------------------------------");
  Cmd.Cout(0,1, "|                                                                                                                      |");
  Cmd.Cout(0,2, "|                                                                                                                      |");
  Cmd.Cout(0,3, "|                                                                                                                      |");
  Cmd.Cout(0,4, "|                                                                                                                      |");
  Cmd.Cout(0,5, "|                                                                                                                      |");
  Cmd.Cout(0,6, "|                                                                                                                      |");
  Cmd.Cout(0,7, "|                                                                                                                      |");
  Cmd.Cout(0,8, "|                                                                                                                      |");
  Cmd.Cout(0,9, "|                                                                                                                      |");
  Cmd.Cout(0,10,"|                                                                                                                      |");
  Cmd.Cout(0,11,"|                                                                                                                      |");
  Cmd.Cout(0,12,"|                                                                                                                      |");
  Cmd.Cout(0,13,"|                                                                                                                      |");
  Cmd.Cout(0,14,"|                                                                                                                      |");
  Cmd.Cout(0,15,"|                                                                                                                      |");
  Cmd.Cout(0,16,"|                                                                                                                      |");
  Cmd.Cout(0,17,"|                                                                                                                      |");
  Cmd.Cout(0,18,"|                                                                                                                      |");
  Cmd.Cout(0,19,"|                                                                                                                      |");
  Cmd.Cout(0,20,"|                                                                                                                      |");
  Cmd.Cout(0,21,"|                                                                                                                      |");
  Cmd.Cout(0,22,"|                                                                                                                      |");
  Cmd.Cout(0,23,"|                                                                                                                      |");
  Cmd.Cout(0,24,"|                                                                                                                      |");
  Cmd.Cout(0,25,"|                                                                                                                      |");
  Cmd.Cout(0,26,"|                                                                                                                      |");
  Cmd.Cout(0,27,"|                                                                                                                      |");
  Cmd.Cout(0,28,"|                                                                                                                      |");
  Cmd.Cout(0,29,"|                                                                                                                      |");
  Cmd.Cout(0,30,"|                                                                                                                      |");
  Cmd.Cout(0,31,"------------------------------------------------------------------------------------------------------------------------");
  for(int o=32; o<=Q; o++)
    Cmd.Cout(0,o,"                                                                                                                       ");
  int tot=0;
  Cmd.Cout(1,++tot,"                                                      ***��Ʒ��***");
  Cmd.Cout(1,++tot,"�������/���ߣ�");
  if(!(tj+jj+sj+td+jd+sd))
    Cmd.Cout(1,++tot," ��");
  else
  {
    if(tj)
      Cmd.Cout(1,++tot," U [����] �� ATK+10  DEF+1    ӵ��"+IntToString(tj)+"��");
    if(jj)
      Cmd.Cout(1,++tot," V [��] �� ATK+50  DEF+5    ӵ��"+IntToString(jj)+"��");
    if(sj)
      Cmd.Cout(1,++tot," U [ʥ��] �� ATK+100 DEF+10   ӵ��"+IntToString(sj)+"��");
    if(td)
      Cmd.Cout(1,++tot," U [����] �� ATK+1  DEF+10    ӵ��"+IntToString(td)+"��");
    if(jd)
      Cmd.Cout(1,++tot," V [���] �� ATK+5  DEF+50    ӵ��"+IntToString(jd)+"��");
    if(sd)
      Cmd.Cout(1,++tot," U [ʥ��] �� ATK+10 DEF+100   ӵ��"+IntToString(sd)+"��");
  }
  Cmd.Cout(1,++tot,"������Ʒ��");
  if(qt_tot==0)
    Cmd.Cout(1,++tot," ��");
  else
    for(int i=tot+1,j=1; i<=30&&j<=qt_tot; i++,j++)
      Cmd.Cout(1,i,qt[j]);
}
int main()
{
  ifstream inf;
  system ("md D:\\mysterious_Palace\\game_archive");
  Cmd.Clear();
  Cmd.Size(122,61);
  Cmd.HideCursor();//���ع��
  Cmd.Clear();
  if(tf==2)
  {
    HP+=36,Map[5][62]='c';
    Map[1][87]='+',Map[1][91]='+',Map[1][95]='d';
  }
  else
  {
    HP+=45;
    Map[5][62]='b',Map[1][86]='b',Map[1][87]='b',Map[1][88]='b',Map[1][91]='+',Map[1][94]='b',Map[1][95]='b',Map[1][96]='b';
    Map[10][26]='+',Map[10][27]='+',Map[10][28]='+';
  }
  for(int i=0; i<Q; i++)
  {
    for(int j=0; j<121; j++)
      if((i==25||i==26||i==27)&&(j==105||j==106))
        cout<<'0';
      else
      {
        if(Map[i][j]=='0')
          Map[i][j]=' ',si0=1;
        cout<<Map[i][j];
        if(si0==1)
          Map[i][j]='0';
        si0=0;
      }
    cout<<endl;
  }
  Map[28][32]=' ',Map[27][32]=' ';
  inf.open("D:\\mysterious_Palace\\game_archive\\system_tf.zsjm");
  inf>>tf;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_X.zsjm");
  inf>>x;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_Y.zsjm");
  inf>>y;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_HP.zsjm");
  inf>>HP;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_ATK.zsjm");
  inf>>ATK;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_DEF.zsjm");
  inf>>DEF;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_FirstKey.zsjm");
  inf>>FirstKey;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_SecondKey.zsjm");
  inf>>SecondKey;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_ThirdKey.zsjm");
  inf>>ThirdKey;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_Weapons.zsjm");
  inf>>Weapons;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_Armor.zsjm");
  inf>>Armor;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_GOLD.zsjm");
  inf>>GOLD;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_name.zsjm");
  inf>>name;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_ks.zsjm");
  inf>>ks;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_tj.zsjm");
  inf>>tj;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_jj.zsjm");
  inf>>jj;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_sj.zsjm");
  inf>>sj;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_td.zsjm");
  inf>>td;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_jd.zsjm");
  inf>>jd;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_sd.zsjm");
  inf>>sd;
  inf.close();
  inf.open("D:\\mysterious_Palace\\game_archive\\system_qt.zsjm");
  while(getline(inf,qt[++qt_tot]));
  qt_tot--;
  inf.close();
  Map[x][y]=' ';
  Cmd.Cout(y,x,"&");
  while(1)
  {
    Cmd.Cout(0,1,"| ");
    if(ks==-1)
    {
      color(4);
      cout<<name<<"-[����]";
      color(7);
    }
    if(ks==0)
    {
      color(1);
      cout<<name<<"-[����]";
      color(7);
    }
    if(ks==1)
    {
      color(5);
      cout<<name<<"-[����]";
      color(7);
    }
    Cmd.Cout(0,2,"| HP:             |");
    Cmd.Cout(0,2,"| HP:"+IntToString(HP));
    Cmd.Cout(0,3,"| ATK:            |");
    Cmd.Cout(0,3,"| ATK:"+IntToString(ATK));
    Cmd.Cout(0,4,"| DEF:            |");
    Cmd.Cout(0,4,"| DEF:"+IntToString(DEF));
    Cmd.Cout(0,5,"| 1��Կ��:        |");
    Cmd.Cout(0,5,"| 1��Կ��:"+IntToString(FirstKey));
    Cmd.Cout(0,6,"| 2��Կ��:        |");
    Cmd.Cout(0,6,"| 2��Կ��:"+IntToString(SecondKey));
    Cmd.Cout(0,7,"| 3��Կ��:        |");
    Cmd.Cout(0,7,"| 3��Կ��:"+IntToString(ThirdKey));
    Cmd.Cout(0,8,"| ����:"+IntToString(Weapons)+"��");
    Cmd.Cout(0,9,"| ����:"+IntToString(Armor)+"��");
    Cmd.Cout(0,10,"| ��Ǯ:           |");
    Cmd.Cout(0,10,"| ��Ǯ:"+IntToString(GOLD));
    tfsc();
    for(int d=0; d<1; d++)
    {
      int c=Cmd.GetKey();
      if(c==48&&jjj==0)
      {
        Cmd.Cout(0,0, "------------------------------------------------------------------------------------------------------------------------");
        Cmd.Cout(0,1, "|                                                                                                                      |");
        Cmd.Cout(0,2, "|                                                                                                                      |");
        Cmd.Cout(0,3, "|                                                                                                                      |");
        Cmd.Cout(0,4, "|                                                                                                                      |");
        Cmd.Cout(0,5, "|                                                                                                                      |");
        Cmd.Cout(0,6, "|                                                                                                                      |");
        Cmd.Cout(0,7, "|                                                                                                                      |");
        Cmd.Cout(0,8, "|                                                                                                                      |");
        Cmd.Cout(0,9, "|                                                                                                                      |");
        Cmd.Cout(0,10,"|                                                                                                                      |");
        Cmd.Cout(0,11,"|                                                                                                                      |");
        Cmd.Cout(0,12,"|                                                                                                                      |");
        Cmd.Cout(0,13,"|                                                                                                                      |");
        Cmd.Cout(0,14,"|                                                                                                                      |");
        Cmd.Cout(0,15,"|                                                                                                                      |");
        Cmd.Cout(0,16,"|                                                                                                                      |");
        Cmd.Cout(0,17,"|                                                                                                                      |");
        Cmd.Cout(0,18,"|                                                                                                                      |");
        Cmd.Cout(0,19,"|                                                                                                                      |");
        Cmd.Cout(0,20,"|                                                                                                                      |");
        Cmd.Cout(0,21,"|                                                                                                                      |");
        Cmd.Cout(0,22,"|                                                                                                                      |");
        Cmd.Cout(0,23,"|                                                                                                                      |");
        Cmd.Cout(0,24,"|                                                                                                                      |");
        Cmd.Cout(0,25,"|                                                                                                                      |");
        Cmd.Cout(0,26,"|                                                                                                                      |");
        Cmd.Cout(0,27,"|                                                                                                                      |");
        Cmd.Cout(0,28,"|                                                                                                                      |");
        Cmd.Cout(0,29,"|                                                                                                                      |");
        Cmd.Cout(0,30,"|                                                                                                                      |");
        Cmd.Cout(0,31,"------------------------------------------------------------------------------------------------------------------------");
        Cmd.Cout(1,1, "��Ϸ����:                                                                                                             ");
        Cmd.Cout(1,2, "��ɲ������Ǹ��Թ�������һ�����غͿӵ���Ϸ�������кܶ����塢���ߡ������Ȼȫ�����˷��ű�ʾ�������㣬��Ҫ�����������");
        Cmd.Cout(1,3, "����250�������249��ɱ��ȥ��ɱ��������ط�����������                                                                  ");
        Cmd.Cout(1,4, "----------------------------------------------------------------------------------------------------------------------");
        Cmd.Cout(1,5, "��Ϸ˵��:                                                                                                             ");
        Cmd.Cout(1,6, "   a b c d e A B C D E ��ʾ���(ע��:����Ҳ���������ص�,�㿴����,ҪС�ı���)                                      ");
        Cmd.Cout(1,7, "   U V W �ֱ��ʾ�������𽣡�ʥ����                                                                                   ");
        Cmd.Cout(1,8, "   X Y Z �ֱ��ʾ���ܡ���ܡ�ʥ�ܡ�                                                                                   ");
        Cmd.Cout(1,9, "   1 2 3��Կ�ף���@ % ��ʾ��Ӧ���š�                                                                                  ");
        Cmd.Cout(1,10,"   HP ��Ѫ������Ѫ��Ϊ��ʱ����Ϸ������                                                                                ");
        Cmd.Cout(1,11,"   ATK �ǹ�������������Խ�ߣ��Թ�����˺�Խ�ߡ�                                                                       ");
        Cmd.Cout(1,12,"   DEF �Ƿ�������������Խ�ߣ��ܵ����˺�Խ�١�                                                                         ");
        Cmd.Cout(1,13,"   * �ǹ�����ʯ���ܼ�2�㹥������                                                                                      ");
        Cmd.Cout(1,14,"   ] �Ƿ�����ʯ���ܼ�2���������                                                                                      ");
        Cmd.Cout(1,15,"   + ��Ѫƿ���ܼ�200��Ѫ����                                                                                          ");
        Cmd.Cout(1,16,"   | = �������ţ�ֻ�����ض�������´򿪡�                                                                             ");
        Cmd.Cout(1,17,"   ) ( �ǵ����ţ�ֻ�ܴӿ��ŵ�һ���ߵ����ŵ�һ�ࡣ                                                                     ");
        Cmd.Cout(1,18,"   ?�ǻ��أ��кõ�Ҳ�л��ģ������ܿ��������ţ�Ҳ�п��ܷɵ����صص㣬���п���ֱ��GAMEOVER������......                  ");
        Cmd.Cout(1,19,"----------------------------------------------------------------------------------------------------------------------");
        Cmd.Cout(1,20,"������ս����:                                                                                                         ");
        Cmd.Cout(1,21,"  a: HP="+IntToString(aHP)+", ATK="+IntToString(aATK)+", DEF="+IntToString(aDEF)+", GOLD="+IntToString(aGOLD)+";");
        Cmd.Cout(1,22,"  b: HP="+IntToString(bHP)+", ATK="+IntToString(bATK)+", DEF="+IntToString(bDEF)+", GOLD="+IntToString(bGOLD)+";");
        Cmd.Cout(1,23,"  c: HP="+IntToString(cHP)+", ATK="+IntToString(cATK)+", DEF="+IntToString(cDEF)+", GOLD="+IntToString(cGOLD)+";");
        Cmd.Cout(1,24,"  d: HP="+IntToString(dHP)+", ATK="+IntToString(dATK)+", DEF="+IntToString(dDEF)+", GOLD="+IntToString(dGOLD)+";");
        Cmd.Cout(1,25,"  e: HP="+IntToString(eHP)+", ATK="+IntToString(eATK)+", DEF="+IntToString(eDEF)+", GOLD="+IntToString(eGOLD)+";");
        Cmd.Cout(1,26,"  A: HP="+IntToString(AHP)+", ATK="+IntToString(AATK)+", DEF="+IntToString(ADEF)+", GOLD="+IntToString(AGOLD)+";");
        Cmd.Cout(1,27,"  B: HP="+IntToString(BHP)+", ATK="+IntToString(BATK)+", DEF="+IntToString(BDEF)+", GOLD="+IntToString(BGOLD)+";");
        Cmd.Cout(1,28,"  C: HP="+IntToString(CHP)+", ATK="+IntToString(CATK)+", DEF="+IntToString(CDEF)+", GOLD="+IntToString(CGOLD)+";");
        Cmd.Cout(1,29,"  D: HP="+IntToString(DHP)+", ATK="+IntToString(DATK)+", DEF="+IntToString(DDEF)+", GOLD="+IntToString(DGOLD)+";");
        Cmd.Cout(1,30,"  E: HP="+IntToString(EHP)+", ATK="+IntToString(EATK)+", DEF="+IntToString(EDEF)+", GOLD="+IntToString(EGOLD)+";");
        for(int o=32; o<=Q; o++)
          Cmd.Cout(0,o,"                                                                                                                       ");
        jjj=1;
      }
      else if(c==48&&jjj==1)
      {
        Cmd.Clear();
        Map[28][32]='#',Map[27][32]='#';
        if(mmm==1)
          Map[7][20]='#',Map[7][21]='#',Map[7][22]='#';
        if(Wen1==1)
        {
          Map[7][24]='1',Map[7][25]='C',Map[7][26]='1',Map[7][27]='C',Map[7][28]='1',Map[7][29]='C',Map[7][30]='1',Map[7][31]='C',Map[7][32]='1',Map[7][33]='?';
          Map[8][24]='C',Map[8][25]='2',Map[8][26]='C',Map[8][27]='2',Map[8][28]='C',Map[8][29]='2',Map[8][30]='C',Map[8][31]='2',Map[8][32]='C',Map[8][33]='2';
        }
        for(int i=0; i<Q; i++)
        {
          for(int j=0; j<121; j++)
            if((i==25||i==26||i==27)&&(j==105||j==106))
              cout<<'0';
            else
            {
              if(Map[i][j]=='0')
                Map[i][j]=' ',si0=1;
              cout<<Map[i][j];
              if(si0==1)
                Map[i][j]='0';
              si0=0;
            }
          cout<<endl;
        }
        Map[28][32]=' ',Map[27][32]=' ';
        if(mmm==1)
          Map[7][20]=' ',Map[7][21]=' ',Map[7][22]=' ';
        Cmd.Cout(y,x,"&");
        Cmd.Cout(0,1,"| ");
        if(ks==-1)
        {
          color(4);
          cout<<name<<"-[����]";
          color(7);
        }
        if(ks==0)
        {
          color(1);
          cout<<name<<"-[����]";
          color(7);
        }
        if(ks==1)
        {
          color(5);
          cout<<name<<"-[����]";
          color(7);
        }
        Cmd.Cout(0,2,"| HP:             |");
        Cmd.Cout(0,2,"| HP:"+IntToString(HP));
        Cmd.Cout(0,3,"| ATK:            |");
        Cmd.Cout(0,3,"| ATK:"+IntToString(ATK));
        Cmd.Cout(0,4,"| DEF:            |");
        Cmd.Cout(0,4,"| DEF:"+IntToString(DEF));
        Cmd.Cout(0,5,"| 1��Կ��:        |");
        Cmd.Cout(0,5,"| 1��Կ��:"+IntToString(FirstKey));
        Cmd.Cout(0,6,"| 2��Կ��:        |");
        Cmd.Cout(0,6,"| 2��Կ��:"+IntToString(SecondKey));
        Cmd.Cout(0,7,"| 3��Կ��:        |");
        Cmd.Cout(0,7,"| 3��Կ��:"+IntToString(ThirdKey));
        Cmd.Cout(0,8,"| ����:"+IntToString(Weapons)+"��");
        Cmd.Cout(0,9,"| ����:"+IntToString(Armor)+"��");
        Cmd.Cout(0,10,"| ��Ǯ:           |");
        Cmd.Cout(0,10,"| ��Ǯ:"+IntToString(GOLD));
        tfsc();
        jjj=0;
      }
      if(c==50&&jjjj==0)
      {
        wupin();
        jjjj=1;
      }
      else if(c==50&&jjjj==1)
      {
        Cmd.Clear();
        Map[28][32]='#',Map[27][32]='#';
        if(mmm==1)
          Map[7][20]='#',Map[7][21]='#',Map[7][22]='#';
        if(Wen1==1)
        {
          Map[7][24]='1',Map[7][25]='C',Map[7][26]='1',Map[7][27]='C',Map[7][28]='1',Map[7][29]='C',Map[7][30]='1',Map[7][31]='C',Map[7][32]='1',Map[7][33]='?';
          Map[8][24]='C',Map[8][25]='2',Map[8][26]='C',Map[8][27]='2',Map[8][28]='C',Map[8][29]='2',Map[8][30]='C',Map[8][31]='2',Map[8][32]='C',Map[8][33]='2';
        }
        for(int i=0; i<Q; i++)
        {
          for(int j=0; j<121; j++)
            if((i==25||i==26||i==27)&&(j==105||j==106))
              cout<<'0';
            else
            {
              if(Map[i][j]=='0')
                Map[i][j]=' ',si0=1;
              cout<<Map[i][j];
              if(si0==1)
                Map[i][j]='0';
              si0=0;
            }
          cout<<endl;
        }
        Map[28][32]=' ',Map[27][32]=' ';
        if(mmm==1)
          Map[7][20]=' ',Map[7][21]=' ',Map[7][22]=' ';
        Cmd.Cout(y,x,"&");
        Cmd.Cout(0,1,"| ");
        if(ks==-1)
        {
          color(4);
          cout<<name<<"-[����]";
          color(7);
        }
        if(ks==0)
        {
          color(1);
          cout<<name<<"-[����]";
          color(7);
        }
        if(ks==1)
        {
          color(5);
          cout<<name<<"-[����]";
          color(7);
        }
        Cmd.Cout(0,2,"| HP:             |");
        Cmd.Cout(0,2,"| HP:"+IntToString(HP));
        Cmd.Cout(0,3,"| ATK:            |");
        Cmd.Cout(0,3,"| ATK:"+IntToString(ATK));
        Cmd.Cout(0,4,"| DEF:            |");
        Cmd.Cout(0,4,"| DEF:"+IntToString(DEF));
        Cmd.Cout(0,5,"| 1��Կ��:        |");
        Cmd.Cout(0,5,"| 1��Կ��:"+IntToString(FirstKey));
        Cmd.Cout(0,6,"| 2��Կ��:        |");
        Cmd.Cout(0,6,"| 2��Կ��:"+IntToString(SecondKey));
        Cmd.Cout(0,7,"| 3��Կ��:        |");
        Cmd.Cout(0,7,"| 3��Կ��:"+IntToString(ThirdKey));
        Cmd.Cout(0,8,"| ����:"+IntToString(Weapons)+"��");
        Cmd.Cout(0,9,"| ����:"+IntToString(Armor)+"��");
        Cmd.Cout(0,10,"| ��Ǯ:           |");
        Cmd.Cout(0,10,"| ��Ǯ:"+IntToString(GOLD));
        tfsc();
        jjjj=0;
      }
      if(c==30&&tf==0&&ATK>0&&DEF>0)
      {
        ATK--;
        DEF--;
        HP+=10;
        Cmd.Cout(0,2,"| HP:             |");
        Cmd.Cout(0,2,"| HP:"+IntToString(HP)+"   ");
        Cmd.Cout(0,3,"| ATK:            |");
        Cmd.Cout(0,3,"| ATK:"+IntToString(ATK)+"   ");
        Cmd.Cout(0,4,"| DEF:            |");
        Cmd.Cout(0,4,"| DEF:"+IntToString(DEF)+"   ");
      }
      if(c==30&&tf==1&&HP>=70&&zb>0)
      {
        Cmd.Cout(y-1,x-1,"***");
        Cmd.Cout(y-1,x,  "* *");
        Cmd.Cout(y-1,x+1,"***");
        Sleep(100);
        Cmd.Cout(y-1,x-1,"   ");
        Cmd.Cout(y-1,x,  " & ");
        Cmd.Cout(y-1,x+1,"   ");
        Sleep(100);
        Cmd.Cout(y-2,x-2,"*****");
        Cmd.Cout(y-2,x-1,"*   *");
        Cmd.Cout(y-2,x,  "*   *");
        Cmd.Cout(y-2,x+1,"*   *");
        Cmd.Cout(y-2,x+2,"*****");
        Sleep(100);
        Cmd.Cout(y-3,x-2,"       ");
        Cmd.Cout(y-3,x-1,"       ");
        Cmd.Cout(y-3,x,  "   &   ");
        Cmd.Cout(y-3,x+1,"       ");
        Cmd.Cout(y-3,x+2,"       ");
        Map[x-2][y-3]=' ',Map[x-2][y-2]=' ',Map[x-2][y-1]=' ',Map[x-2][y]=' ',Map[x-2][y+1]=' ',Map[x-2][y+2]=' ',Map[x-2][y+3]=' ';
        Map[x-1][y-3]=' ',Map[x-1][y-2]=' ',Map[x-1][y-1]=' ',Map[x-1][y]=' ',Map[x-1][y+1]=' ',Map[x-1][y+2]=' ',Map[x-1][y+3]=' ';
        Map[x][y-3]=' ',  Map[x][y-2]=' ',  Map[x][y-1]=' ',  Map[x][y]=' ',  Map[x][y+1]=' ',  Map[x][y+2]=' ',  Map[x][y+3]=' ';
        Map[x+1][y-3]=' ',Map[x+1][y-2]=' ',Map[x+1][y-1]=' ',Map[x+1][y]=' ',Map[x+1][y+1]=' ',Map[x+1][y+2]=' ',Map[x+1][y+3]=' ';
        Map[x+2][y-3]=' ',Map[x+2][y-2]=' ',Map[x+2][y-1]=' ',Map[x+2][y]=' ',Map[x+2][y+1]=' ',Map[x+2][y+2]=' ',Map[x+2][y+3]=' ';
        HP=1;
        zb--;
        Cmd.Cout(0,2,"| HP:             |");
        Cmd.Cout(0,2,"| HP:"+IntToString(HP)+"   ");
        Cmd.Cout(0,11,"|                 |");
        Cmd.Cout(0,11,"| �츳:�Ա�("+IntToString(zb)+"��)  |");
      }
      if(tf==2) {};
      if(tf==3) {};
      if(tf==4) {};
      if(c==44)
      {
        int xl;
        Cmd.Clear();
        cout<<"|---------------------------------|\n";
        cout<<"|                                 |\n";
        cout<<"|  �Ƿ��ʼ���˹ؿ�[�����ѡ��]   |\n";
        cout<<"|                                 |\n";
        cout<<"|  1.��[��ʼ����Ϸ,���¿�ʼ��Ϸ]  |\n";
        cout<<"|  2.��[������Ϸҳ��,������Ϸ]    |\n";
        cout<<"|                                 |\n";
        cout<<"|---------------------------------|\n";
        cout<<"������:";
        cin>>xl;
        int x1=11,x2=12,x3=13;
        if(xl==1)
        {
          cout<<"-->-->-->-->-->-->-->-->-->-->-->\n";
          cout<<"������......\n";
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|                    |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_X.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|��                  |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_Y.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|����                |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_HP.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|������              |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_ATK.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|��������            |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_DEF.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|����������          |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_FirstKey.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|������������        |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_SecondKey.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|��������������      |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_ThirdKey.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|����������������    |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_Weapons.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|������������������  |");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_Armor.zsjm");
          Cmd.Cout(0,x1,"|--------------------|");
          Cmd.Cout(0,x2,"|��������������������|");
          Cmd.Cout(0,x3,"|--------------------|");
          cout<<'\n';
          system("del D:\\mysterious_Palace\\game_archive\\system_GOLD.zsjm");
          Cmd.Clear();
          cout<<"                                \n";
          cout<<"  ******************************\n";
          cout<<"  *�ѳɹ���ʼ��                *\n";
          cout<<"  *�ؿ�����Ч[���»س��ر���Ϸ]*\n";
          cout<<"  ******************************\n";
          return 0;
        }
        else
        {
          Cmd.Clear();
          Map[28][32]='#',Map[27][32]='#';
          if(mmm==1)
            Map[7][20]='#',Map[7][21]='#',Map[7][22]='#';
          if(Wen1==1)
          {
            Map[7][24]='1',Map[7][25]='C',Map[7][26]='1',Map[7][27]='C',Map[7][28]='1',Map[7][29]='C',Map[7][30]='1',Map[7][31]='C',Map[7][32]='1',Map[7][33]='?';
            Map[8][24]='C',Map[8][25]='2',Map[8][26]='C',Map[8][27]='2',Map[8][28]='C',Map[8][29]='2',Map[8][30]='C',Map[8][31]='2',Map[8][32]='C',Map[8][33]='2';
          }
          for(int i=0; i<Q; i++)
          {
            for(int j=0; j<121; j++)
              if((i==25||i==26||i==27)&&(j==105||j==106))
                cout<<'0';
              else
              {
                if(Map[i][j]=='0')
                  Map[i][j]=' ',si0=1;
                cout<<Map[i][j];
                if(si0==1)
                  Map[i][j]='0';
                si0=0;
              }
            cout<<endl;
          }
          Map[28][32]=' ',Map[27][32]=' ';
          if(mmm==1)
            Map[7][20]=' ',Map[7][21]=' ',Map[7][22]=' ';
          Cmd.Cout(y,x,"&");
          Cmd.Cout(0,1,"| ");
          if(ks==-1)
          {
            color(4);
            cout<<name<<"-[����]";
            color(7);
          }
          if(ks==0)
          {
            color(1);
            cout<<name<<"-[����]";
            color(7);
          }
          if(ks==1)
          {
            color(5);
            cout<<name<<"-[����]";
            color(7);
          }
          Cmd.Cout(0,2,"| HP:             |");
          Cmd.Cout(0,2,"| HP:"+IntToString(HP));
          Cmd.Cout(0,3,"| ATK:            |");
          Cmd.Cout(0,3,"| ATK:"+IntToString(ATK));
          Cmd.Cout(0,4,"| DEF:            |");
          Cmd.Cout(0,4,"| DEF:"+IntToString(DEF));
          Cmd.Cout(0,5,"| 1��Կ��:        |");
          Cmd.Cout(0,5,"| 1��Կ��:"+IntToString(FirstKey));
          Cmd.Cout(0,6,"| 2��Կ��:        |");
          Cmd.Cout(0,6,"| 2��Կ��:"+IntToString(SecondKey));
          Cmd.Cout(0,7,"| 3��Կ��:        |");
          Cmd.Cout(0,7,"| 3��Կ��:"+IntToString(ThirdKey));
          Cmd.Cout(0,8,"| ����:"+IntToString(Weapons)+"��");
          Cmd.Cout(0,9,"| ����:"+IntToString(Armor)+"��");
          Cmd.Cout(0,10,"| ��Ǯ:           |");
          Cmd.Cout(0,10,"| ��Ǯ:"+IntToString(GOLD));
          tfsc();
        }
      }
      if(c==25)
      {
        string xl;
        Cmd.Clear();
        cout<<"-------------[����ר��]------------\n";
        cout<<"�������������:";
        cin>>xl;
        if(xl=="mp-gly")
        {
          Cmd.Cout(0,1,"�������������:******");
          cout<<'\n';
          cout<<"�Ƿ����ø���[1Ϊ��,0Ϊ��]:";
          int llx;
          cin>>llx;
          cout<<"������HP��";
          cin>>HP;
          cout<<"������ATK��";
          cin>>ATK;
          cout<<"������DEF��";
          cin>>DEF;
          cout<<"������1��Կ�ף�";
          cin>>FirstKey;
          cout<<"������2��Կ�ף�";
          cin>>SecondKey;
          cout<<"������3��Կ�ף�";
          cin>>ThirdKey;
          cout<<"�������Ǯ��";
          cin>>GOLD;
          if(llx==1)
          {
            ofstream outf;
            outf.open("D:\\mysterious_Palace\\game_archive\\system_HP.zsjm");
            outf<<HP;
            outf.close();
            outf.open("D:\\mysterious_Palace\\game_archive\\system_ATK.zsjm");
            outf<<ATK;
            outf.close();
            outf.open("D:\\mysterious_Palace\\game_archive\\system_DEF.zsjm");
            outf<<DEF;
            outf.close();
            outf.open("D:\\mysterious_Palace\\game_archive\\system_FirstKey.zsjm");
            outf<<FirstKey;
            outf.close();
            outf.open("D:\\mysterious_Palace\\game_archive\\system_SecondKey.zsjm");
            outf<<SecondKey;
            outf.close();
            outf.open("D:\\mysterious_Palace\\game_archive\\system_ThirdKey.zsjm");
            outf<<ThirdKey;
            outf.close();
            outf.open("D:\\mysterious_Palace\\game_archive\\system_GOLD.zsjm");
            outf<<GOLD;
            outf.close();
          }
          cout<<"�����ɹ�! (���»س�������Ϸ)";
        }
        else
          cout<<"�������! (���»س�������Ϸ)";
        getchar();
        getchar();
        Cmd.Clear();
        Map[28][32]='#',Map[27][32]='#';
        if(mmm==1)
          Map[7][20]='#',Map[7][21]='#',Map[7][22]='#';
        if(Wen1==1)
        {
          Map[7][24]='1',Map[7][25]='C',Map[7][26]='1',Map[7][27]='C',Map[7][28]='1',Map[7][29]='C',Map[7][30]='1',Map[7][31]='C',Map[7][32]='1',Map[7][33]='?';
          Map[8][24]='C',Map[8][25]='2',Map[8][26]='C',Map[8][27]='2',Map[8][28]='C',Map[8][29]='2',Map[8][30]='C',Map[8][31]='2',Map[8][32]='C',Map[8][33]='2';
        }
        for(int i=0; i<Q; i++)
        {
          for(int j=0; j<121; j++)
            if((i==25||i==26||i==27)&&(j==105||j==106))
              cout<<'0';
            else
            {
              if(Map[i][j]=='0')
                Map[i][j]=' ',si0=1;
              cout<<Map[i][j];
              if(si0==1)
                Map[i][j]='0';
              si0=0;
            }
          cout<<endl;
        }
        Map[28][32]=' ',Map[27][32]=' ';
        if(mmm==1)
          Map[7][20]=' ',Map[7][21]=' ',Map[7][22]=' ';
        Cmd.Cout(y,x,"&");
        Cmd.Cout(0,1,"| ");
        if(ks==-1)
        {
          color(4);
          cout<<name<<"-[����]";
          color(7);
        }
        if(ks==0)
        {
          color(1);
          cout<<name<<"-[����]";
          color(7);
        }
        if(ks==1)
        {
          color(5);
          cout<<name<<"-[����]";
          color(7);
        }
        Cmd.Cout(0,2,"| HP:             |");
        Cmd.Cout(0,2,"| HP:"+IntToString(HP));
        Cmd.Cout(0,3,"| ATK:            |");
        Cmd.Cout(0,3,"| ATK:"+IntToString(ATK));
        Cmd.Cout(0,4,"| DEF:            |");
        Cmd.Cout(0,4,"| DEF:"+IntToString(DEF));
        Cmd.Cout(0,5,"| 1��Կ��:        |");
        Cmd.Cout(0,5,"| 1��Կ��:"+IntToString(FirstKey));
        Cmd.Cout(0,6,"| 2��Կ��:        |");
        Cmd.Cout(0,6,"| 2��Կ��:"+IntToString(SecondKey));
        Cmd.Cout(0,7,"| 3��Կ��:        |");
        Cmd.Cout(0,7,"| 3��Կ��:"+IntToString(ThirdKey));
        Cmd.Cout(0,8,"| ����:"+IntToString(Weapons)+"��");
        Cmd.Cout(0,9,"| ����:"+IntToString(Armor)+"��");
        tfsc();
        Cmd.Cout(0,10,"| ��Ǯ:           |");
        Cmd.Cout(0,10,"| ��Ǯ:"+IntToString(GOLD));
      }
      if(c==72 && Map[x-1][y]==' ')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
      }
      else if(c==80 && Map[x+1][y]==' ')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
      }
      else if(c==75 && Map[x][y-1]==' ')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
      }
      else if(c==77 && Map[x][y+1]==' ')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
      }
      else if(c==77 && Map[x][y+1]=='1')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        FirstKey+=1;
      }
      else if(c==75 && Map[x][y-1]=='1')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        FirstKey+=1;
      }
      else if(c==80 && Map[x+1][y]=='1')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        FirstKey+=1;
      }
      else if(c==72 && Map[x-1][y]=='1')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        FirstKey+=1;
      }
      else if(c==77 && Map[x][y+1]=='!' && FirstKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        FirstKey-=1;
      }
      else if(c==75 && Map[x][y-1]=='!' && FirstKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        FirstKey-=1;
      }
      else if(c==80 && Map[x+1][y]=='!' && FirstKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        FirstKey-=1;
      }
      else if(c==72 && Map[x-1][y]=='!' && FirstKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        FirstKey-=1;
      }
      else if(c==77 && Map[x][y+1]=='2')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        SecondKey+=1;
      }
      else if(c==75 && Map[x][y-1]=='2')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        SecondKey+=1;
      }
      else if(c==80 && Map[x+1][y]=='2')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        SecondKey+=1;
      }
      else if(c==72 && Map[x-1][y]=='2')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        SecondKey+=1;
      }
      else if(c==77 && Map[x][y+1]=='@' && SecondKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        SecondKey-=1;
      }
      else if(c==75 && Map[x][y-1]=='@' && SecondKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        SecondKey-=1;
      }
      else if(c==80 && Map[x+1][y]=='@' && SecondKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        SecondKey-=1;
      }
      else if(c==72 && Map[x-1][y]=='@' && SecondKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        SecondKey-=1;
      }
      else if(c==77 && Map[x][y+1]=='3')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ThirdKey+=1;
      }
      else if(c==75 && Map[x][y-1]=='3')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ThirdKey+=1;
      }
      else if(c==80 && Map[x+1][y]=='3')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ThirdKey+=1;
      }
      else if(c==72 && Map[x-1][y]=='3')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ThirdKey+=1;
      }
      else if(c==77 && Map[x][y+1]=='%' && ThirdKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ThirdKey-=1;
      }
      else if(c==75 && Map[x][y-1]=='%' && ThirdKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ThirdKey-=1;
      }
      else if(c==80 && Map[x+1][y]=='%' && ThirdKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ThirdKey-=1;
      }
      else if(c==72 && Map[x-1][y]=='%' && ThirdKey>=1)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ThirdKey-=1;
      }
      else if(c==77 && Map[x][y+1]=='a')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<aATK)
          HP-=aHP/ATK*aATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=aGOLD;
        GAMEOVER='a';
      }
      else if(c==75 && Map[x][y-1]=='a')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<aATK)
          HP-=aHP/ATK*aATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=aGOLD;
        GAMEOVER='a';
      }
      else if(c==80 && Map[x+1][y]=='a')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<aATK)
          HP-=aHP/ATK*aATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=aGOLD;
        GAMEOVER='a';
      }
      else if(c==72 && Map[x-1][y]=='a')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<aATK)
          HP-=aHP/ATK*aATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=aGOLD;
        GAMEOVER='a';
      }
      else if(c==77 && Map[x][y+1]=='b')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<bATK)
          HP-=bHP/ATK*bATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=bGOLD;
        GAMEOVER='b';
      }
      else if(c==75 && Map[x][y-1]=='b')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<bATK)
          HP-=bHP/ATK*bATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=bGOLD;
        GAMEOVER='b';
      }
      else if(c==80 && Map[x+1][y]=='b')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<bATK)
          HP-=bHP/ATK*bATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=bGOLD;
        GAMEOVER='b';
      }
      else if(c==72 && Map[x-1][y]=='b')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<bATK)
          HP-=bHP/ATK*bATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=bGOLD;
        GAMEOVER='b';
      }
      else if(c==77 && Map[x][y+1]=='c')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<cATK)
          HP-=cHP/ATK*cATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=cGOLD;
        GAMEOVER='c';
      }
      else if(c==75 && Map[x][y-1]=='c')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<cATK)
          HP-=cHP/ATK*cATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=cGOLD;
        GAMEOVER='c';
      }
      else if(c==80 && Map[x+1][y]=='c')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<cATK)
          HP-=cHP/ATK*cATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=cGOLD;
        GAMEOVER='c';
      }
      else if(c==72 && Map[x-1][y]=='c')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<cATK)
          HP-=cHP/ATK*cATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=cGOLD;
        GAMEOVER='c';
      }
      else if(c==77 && Map[x][y+1]=='d')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<dATK)
          HP-=dHP/ATK*dATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=dGOLD;
        GAMEOVER='d';
      }
      else if(c==75 && Map[x][y-1]=='d')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<dATK)
          HP-=dHP/ATK*dATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=dGOLD;
        GAMEOVER='d';
      }
      else if(c==80 && Map[x+1][y]=='d')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<dATK)
          HP-=dHP/ATK*dATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=dGOLD;
        GAMEOVER='d';
      }
      else if(c==72 && Map[x-1][y]=='d')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<dATK)
          HP-=dHP/ATK*dATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=dGOLD;
        GAMEOVER='d';
      }
      else if(c==77 && Map[x][y+1]=='e')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<eATK)
          HP-=eHP/ATK*eATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=eGOLD;
        GAMEOVER='e';
      }
      else if(c==75 && Map[x][y-1]=='e')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<eATK)
          HP-=eHP/ATK*eATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=eGOLD;
        GAMEOVER='e';
      }
      else if(c==80 && Map[x+1][y]=='e')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<eATK)
          HP-=eHP/ATK*eATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=eGOLD;
        GAMEOVER='e';
      }
      else if(c==72 && Map[x-1][y]=='e')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<eATK)
          HP-=eHP/ATK*eATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=eGOLD;
        GAMEOVER='e';
      }
      else if(c==77 && Map[x][y+1]=='A')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<AATK)
          HP-=AHP/ATK*AATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=AGOLD;
        GAMEOVER='A';
      }
      else if(c==75 && Map[x][y-1]=='A')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<AATK)
          HP-=AHP/ATK*AATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=AGOLD;
        GAMEOVER='A';
      }
      else if(c==80 && Map[x+1][y]=='A')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<AATK)
          HP-=AHP/ATK*AATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=AGOLD;
        GAMEOVER='A';
      }
      else if(c==72 && Map[x-1][y]=='A')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<AATK)
          HP-=AHP/ATK*AATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=AGOLD;
        GAMEOVER='A';
      }
      else if(c==77 && Map[x][y+1]=='B')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<BATK)
          HP-=BHP/ATK*BATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=BGOLD;
        GAMEOVER='B';
      }
      else if(c==75 && Map[x][y-1]=='B')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<BATK)
          HP-=BHP/ATK*BATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=BGOLD;
        GAMEOVER='B';
      }
      else if(c==80 && Map[x+1][y]=='B')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<BATK)
          HP-=BHP/ATK*BATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=BGOLD;
        GAMEOVER='B';
      }
      else if(c==72 && Map[x-1][y]=='B')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<BATK)
          HP-=BHP/ATK*BATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=BGOLD;
        GAMEOVER='B';
      }
      else if(c==77 && Map[x][y+1]=='C')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<CATK)
          HP-=CHP/ATK*CATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=CGOLD;
        GAMEOVER='C';
      }
      else if(c==75 && Map[x][y-1]=='C')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<CATK)
          HP-=CHP/ATK*CATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=CGOLD;
        GAMEOVER='C';
      }
      else if(c==80 && Map[x+1][y]=='C')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<CATK)
          HP-=CHP/ATK*CATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=CGOLD;
        GAMEOVER='C';
      }
      else if(c==72 && Map[x-1][y]=='C')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<CATK)
          HP-=CHP/ATK*CATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=CGOLD;
        GAMEOVER='C';
      }
      else if(c==77 && Map[x][y+1]=='D')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<DATK)
          HP-=DHP/ATK*DATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=DGOLD;
        GAMEOVER='D';
      }
      else if(c==75 && Map[x][y-1]=='D')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<DATK)
          HP-=DHP/ATK*DATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=DGOLD;
        GAMEOVER='D';
      }
      else if(c==80 && Map[x+1][y]=='D')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<DATK)
          HP-=DHP/ATK*DATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=DGOLD;
        GAMEOVER='D';
      }
      else if(c==72 && Map[x-1][y]=='D')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<DATK)
          HP-=DHP/ATK*DATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=DGOLD;
        GAMEOVER='D';
      }
      else if(c==77 && Map[x][y+1]=='E')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<EATK)
          HP-=EHP/ATK*EATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=EGOLD;
        GAMEOVER='E';
      }
      else if(c==75 && Map[x][y-1]=='E')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<EATK)
          HP-=EHP/ATK*EATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=EGOLD;
        GAMEOVER='E';
      }
      else if(c==80 && Map[x+1][y]=='E')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<EATK)
          HP-=EHP/ATK*EATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=EGOLD;
        GAMEOVER='E';
      }
      else if(c==72 && Map[x-1][y]=='E')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<EATK)
          HP-=EHP/ATK*EATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=EGOLD;
        GAMEOVER='E';
      }
      else if(c==77 && Map[x][y+1]=='M')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<MATK)
          HP-=MHP/ATK*MATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=MGOLD;
        GAMEOVER='M';
      }
      else if(c==75 && Map[x][y-1]=='M')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<MATK)
          HP-=MHP/ATK*MATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=MGOLD;
        GAMEOVER='M';
      }
      else if(c==80 && Map[x+1][y]=='M')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<MATK)
          HP-=MHP/ATK*MATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=MGOLD;
        GAMEOVER='M';
      }
      else if(c==72 && Map[x-1][y]=='M')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF+=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        if(DEF<MATK)
          HP-=MHP/ATK*MATK-DEF;
        ATK-=tj*10+jj*50+sj*100+td*1+jd*5+sd*10;
        DEF-=tj*1+jj*5+sj*10+td*10+jd*50+sd*100;
        GOLD+=MGOLD;
        GAMEOVER='M';
      }
      else if(c==77 && Map[x][y+1]=='+')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        HP+=200;
      }
      else if(c==75 && Map[x][y-1]=='+')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        HP+=200;
      }
      else if(c==80 && Map[x+1][y]=='+')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        HP+=200;
      }
      else if(c==72 && Map[x-1][y]=='+')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=200;
      }
      else if(c==77 && Map[x][y+1]==']')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        DEF+=2;
      }
      else if(c==75 && Map[x][y-1]==']')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        DEF+=2;
      }
      else if(c==80 && Map[x+1][y]==']')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        DEF+=2;
      }
      else if(c==72 && Map[x-1][y]==']')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        DEF+=2;
      }
      else if(c==77 && Map[x][y+1]=='*')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        ATK+=2;
      }
      else if(c==75 && Map[x][y-1]=='*')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        ATK+=2;
      }
      else if(c==80 && Map[x+1][y]=='*')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        ATK+=2;
      }
      else if(c==72 && Map[x-1][y]=='*')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        ATK+=2;
      }
      else if(c==77 && Map[x][y+1]=='0')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        GAMEOVER='0';
        HP=0;
      }
      else if(c==75 && Map[x][y-1]=='0')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        GAMEOVER='0';
        HP=0;
      }
      else if(c==80 && Map[x+1][y]=='0')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        GAMEOVER='0';
        HP=0;
      }
      else if(c==72 && Map[x-1][y]=='0')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        GAMEOVER='0';
        HP=0;
      }
      else if(c==77 && Map[x][y+1]=='U')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("����");
      }
      else if(c==75 && Map[x][y-1]=='U')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("����");
      }
      else if(c==80 && Map[x+1][y]=='U')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("����");
      }
      else if(c==72 && Map[x-1][y]=='U')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("����");
      }
      else if(c==77 && Map[x][y+1]=='V')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("��");
      }
      else if(c==75 && Map[x][y-1]=='V')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("��");
      }
      else if(c==80 && Map[x+1][y]=='V')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("��");
      }
      else if(c==72 && Map[x-1][y]=='V')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("��");
      }
      else if(c==77 && Map[x][y+1]=='W')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("ʥ��");
      }
      else if(c==75 && Map[x][y-1]=='W')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("ʥ��");
      }
      else if(c==80 && Map[x+1][y]=='W')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("ʥ��");
      }
      else if(c==72 && Map[x-1][y]=='W')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        Weapons++;
        jz("ʥ��");
      }
      else if(c==77 && Map[x][y+1]=='X')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("����");
      }
      else if(c==75 && Map[x][y-1]=='X')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("����");
      }
      else if(c==80 && Map[x+1][y]=='X')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("����");
      }
      else if(c==72 && Map[x-1][y]=='X')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("����");
      }
      else if(c==77 && Map[x][y+1]=='Y')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("���");
      }
      else if(c==75 && Map[x][y-1]=='Y')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("���");
      }
      else if(c==80 && Map[x+1][y]=='Y')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("���");
      }
      else if(c==72 && Map[x-1][y]=='Y')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("���");
      }
      else if(c==77 && Map[x][y+1]=='Z')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("ʥ��");
      }
      else if(c==75 && Map[x][y-1]=='Z')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("ʥ��");
      }
      else if(c==80 && Map[x+1][y]=='Z')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("ʥ��");
      }
      else if(c==72 && Map[x-1][y]=='Z')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        Armor++;
        jz("ʥ��");
      }
      else if(c==77 && Map[x][y+1]==')')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y+2,x,"&");
        y+=2;
      }
      else if(c==75 && Map[x][y-1]=='(')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y-2,x,"&");
        y-=2;
      }
      else if(c==77 && x==1 && y+1==31)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        HP/=2;
        ATK/=2;
        DEF/=2;
        FirstKey/=2;
        SecondKey/=2;
        ThirdKey/=2;
        Weapons/=2;
        Armor/=2;
        GOLD/=2;
        GAMEOVER='?';
      }
      else if(c==75 && x==1 && y-1==31)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        HP/=2;
        ATK/=2;
        DEF/=2;
        FirstKey/=2;
        SecondKey/=2;
        ThirdKey/=2;
        Weapons/=2;
        Armor/=2;
        GOLD/=2;
        GAMEOVER='?';
      }
      else if(c==80 && x+1==1 && y==31)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        HP/=2;
        ATK/=2;
        DEF/=2;
        FirstKey/=2;
        SecondKey/=2;
        ThirdKey/=2;
        Weapons/=2;
        Armor/=2;
        GOLD/=2;
        GAMEOVER='?';
      }
      else if(c==72 && x-1==1 && y==31)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP/=2;
        ATK/=2;
        DEF/=2;
        FirstKey/=2;
        SecondKey/=2;
        ThirdKey/=2;
        Weapons/=2;
        Armor/=2;
        GOLD/=2;
        GAMEOVER='?';
      }
      else if(c==77 && x==1 && y+1==98)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        if(tf==2)
          HP-=93;
        HP*=10;
        ATK+=5;
        DEF+=5;
        FirstKey=0;
        SecondKey=0;
        ThirdKey=0;
        Weapons=0;
        Armor=0;
        GOLD=0;
        Map[0][31]=' ',Map[0][32]=' ',Map[0][33]=' ';
      }
      else if(c==75 && x==10 && y-1==21)
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        Cmd.Cout(24,7,"1C1C1C1C1?");
        Cmd.Cout(24,8,"C2C2C2C2C2");
        Cmd.Cout(20,9,"   ");
        Wen1=1;
        Map[9][20]=' ',Map[9][21]=' ',Map[9][22]=' ';
        Map[7][24]='1',Map[7][25]='C',Map[7][26]='1',Map[7][27]='C',Map[7][28]='1',Map[7][29]='C',Map[7][30]='1',Map[7][31]='C',Map[7][32]='1',Map[7][33]='?';
        Map[8][24]='C',Map[8][25]='2',Map[8][26]='C',Map[8][27]='2',Map[8][28]='C',Map[8][29]='2',Map[8][30]='C',Map[8][31]='2',Map[8][32]='C',Map[8][33]='2';
      }
      else if(c==72 && x-1==7 && y==33 && Map[7][33]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Cmd.Cout(20,7,"   ");
        Map[7][20]=' ',Map[7][21]=' ',Map[7][22]=' ';
        Map[x][y]=' ';
        Wen1=0;
        mmm=1;
        HP+=500;
      }
      else if(c==77 && x==7 && y+1==33 && Map[7][33]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Cmd.Cout(20,7,"   ");
        Map[7][20]=' ',Map[7][21]=' ',Map[7][22]=' ';
        Map[x][y]=' ';
        Wen1=0;
        mmm=1;
        HP+=500;
      }
      else if(c==77 && x==19 && y+1==24 && Map[19][24]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Cmd.Cout(8,20," ");
        Map[x][y]=' ';
        Map[20][8]=' ';
      }
      else if(c==75 && x==19 && y-1==24 && Map[19][24]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Cmd.Cout(8,20," ");
        Map[x][y]=' ';
        Map[20][8]=' ';
      }
      else if(c==80 && x+1==19 && y==24 && Map[19][24]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Cmd.Cout(8,20," ");
        Map[x][y]=' ';
        Map[20][8]=' ';
      }
      else if(c==72 && x-1==19 && y==24 && Map[19][24]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Cmd.Cout(8,20," ");
        Map[x][y]=' ';
        Map[20][8]=' ';
      }
      else if(c==77 && x==35 && y+1==7 && Map[35][7]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        DEF+=10;
        ATK+=10;
        HP-=500;
        GAMEOVER='?';
      }
      else if(c==75 && x==35 && y-1==7 && Map[35][7]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        DEF+=10;
        ATK+=10;
        HP-=500;
        GAMEOVER='?';
      }
      else if(c==80 && x+1==35 && y==7 && Map[35][7]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        DEF+=10;
        ATK+=10;
        HP-=500;
        GAMEOVER='?';
      }
      else if(c==72 && x-1==35 && y==7 && Map[35][7]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        DEF+=10;
        ATK+=10;
        HP-=500;
        GAMEOVER='?';
      }
      else if(c==77 && x==33 && y+1==32 && Map[33][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,33," ");
        Map[33][32]=' ';
        x=1,y=20;
        Cmd.Cout(y,x,"&");
      }
      else if(c==75 && x==33 && y-1==32 && Map[33][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,33," ");
        Map[33][32]=' ';
        x=1,y=20;
        Cmd.Cout(y,x,"&");
      }
      else if(c==80 && x+1==33 && y==32 && Map[33][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,33," ");
        Map[33][32]=' ';
        x=1,y=20;
        Cmd.Cout(y,x,"&");
      }
      else if(c==72 && x-1==33 && y==32 && Map[33][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,33," ");
        Map[33][32]=' ';
        x=1,y=20;
        Cmd.Cout(y,x,"&");
      }
      else if(c==77 && x==35 && y+1==32 && Map[35][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,35," ");
        Map[35][32]=' ';
        x=19,y=30;
        Cmd.Cout(y,x,"&");
      }
      else if(c==75 && x==35 && y-1==32 && Map[35][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,35," ");
        Map[35][32]=' ';
        x=19,y=30;
        Cmd.Cout(y,x,"&");
      }
      else if(c==80 && x+1==35 && y==32 && Map[35][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,35," ");
        Map[35][32]=' ';
        x=19,y=30;
        Cmd.Cout(y,x,"&");
      }
      else if(c==72 && x-1==35 && y==32 && Map[35][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,35," ");
        Map[35][32]=' ';
        x=19,y=30;
        Cmd.Cout(y,x,"&");
      }
      else if(c==77 && x==29 && y+1==32 && Map[29][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,29," ");
        Map[29][32]=' ';
        x=18,y=52;
        Cmd.Cout(y,x,"&");
      }
      else if(c==75 && x==29 && y-1==32 && Map[29][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,29," ");
        Map[29][32]=' ';
        x=18,y=52;
        Cmd.Cout(y,x,"&");
      }
      else if(c==80 && x+1==29 && y==32 && Map[29][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,29," ");
        Map[29][32]=' ';
        x=18,y=52;
        Cmd.Cout(y,x,"&");
      }
      else if(c==72 && x-1==29 && y==32 && Map[29][32]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(32,29," ");
        Map[29][32]=' ';
        x=18,y=52;
        Cmd.Cout(y,x,"&");
      }
      else if(c==77 && x==19 && y+1==34 && Map[19][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        HP-=1000;
        GAMEOVER='?';
      }
      else if(c==75 && x==19&& y-1==34 && Map[19][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[x][y]=' ';
        HP-=1000;
        GAMEOVER='?';
      }
      else if(c==80 && x+1==19 && y==34 && Map[19][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        HP-=1000;
        GAMEOVER='?';
      }
      else if(c==72 && x-1==19 && y==34 && Map[19][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP-=1000;
        GAMEOVER='?';
      }
      else if(c==77 && x==35 && y+1==117 && Map[35][117]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[35][117]=' ';
        tf=1;
        tfsc();
      }
      else if(c==75 && x==35 && y-1==117 && Map[35][117]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[35][117]=' ';
        tf=1;
        tfsc();
      }
      else if(c==80 && x+1==35 && y==117 && Map[35][117]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[35][117]=' ';
        tf=1;
        tfsc();
      }
      else if(c==72 && x-1==35 && y==117 && Map[35][117]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[35][117]=' ';
        tf=1;
        tfsc();
      }
      else if(c==77 && x==35 && y+1==111 && Map[35][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[35][111]=' ';
        tf=2;
        tfsc();
      }
      else if(c==75 && x==35 && y-1==111 && Map[35][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[35][111]=' ';
        tf=2;
        tfsc();
      }
      else if(c==80 && x+1==35 && y==111 && Map[35][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[35][111]=' ';
        tf=2;
        tfsc();
      }
      else if(c==72 && x-1==35 && y==111 && Map[35][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[35][111]=' ';
        tf=2;
        tfsc();
      }
      else if(c==77 && x==34 && y+1==111 && Map[34][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[34][111]=' ';
        tf=0;
        tfsc();
      }
      else if(c==75 && x==34 && y-1==111 && Map[34][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[34][111]=' ';
        tf=0;
        tfsc();
      }
      else if(c==80 && x+1==34 && y==111 && Map[34][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[34][111]=' ';
        tf=0;
        tfsc();
      }
      else if(c==72 && x-1==34 && y==111 && Map[34][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[34][111]=' ';
        tf=0;
        tfsc();
      }
      else if(c==77 && x==33 && y+1==111 && Map[33][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[33][111]=' ';
        tf=3;
        tfsc();
      }
      else if(c==75 && x==33 && y-1==111 && Map[33][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(--y,x,"&");
        Map[33][111]=' ';
        tf=3;
        tfsc();
      }
      else if(c==80 && x+1==33 && y==111 && Map[33][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[33][111]=' ';
        tf=3;
        tfsc();
      }
      else if(c==72 && x-1==33 && y==111 && Map[33][111]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[33][111]=' ';
        tf=3;
        tfsc();
      }
      else if(c==77 && x==28 && y+1==82 && Map[28][82]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(++y,x,"&");
        Map[x][y]=' ';
        HP*=10;
        Cmd.Cout(48,21,"|----------------------|");
        Cmd.Cout(48,22,"|M��BOOS               |");
        Cmd.Cout(48,23,"|HP=20000, ATK=5000    |");
        Cmd.Cout(48,24,"|DEF=5000,  GOLD=10000 |");
        Cmd.Cout(48,25,"|���BOOS���������һһ|");
        Cmd.Cout(48,26,"|������,��һ���Ǹ�����!|");
        Cmd.Cout(48,27,"|----------------------|");
        Map[27][48]='#',Map[27][49]='#',Map[27][50]='#',Map[27][51]='#',Map[27][52]='#';
        Map[27][53]='#',Map[27][54]='#',Map[27][55]='#',Map[27][56]='#',Map[27][57]='#';
        Map[27][58]='#',Map[27][59]='#',Map[27][60]='#',Map[27][61]='#',Map[27][62]='#';
        Map[27][63]='#',Map[27][64]='#',Map[27][65]='#',Map[27][66]='#',Map[27][67]='#';
        Map[27][68]='#',Map[27][69]='#',Map[27][70]='#',Map[27][71]='#';
      }
      else if(c==80 && x+1==29 && y==83 && Map[29][83]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        HP-=10000;
      }
      else if(c==80 && x+1==33 && y==39 && Map[33][39]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        Cmd.Clear();
        ofstream outf;
        outf.open("D:\\mysterious_Palace\\game_archive\\system_X.zsjm");
        outf<<1;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Y.zsjm");
        outf<<20;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_HP.zsjm");
        outf<<HP;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_ATK.zsjm");
        outf<<ATK;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_DEF.zsjm");
        outf<<DEF;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_FirstKey.zsjm");
        outf<<FirstKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_SecondKey.zsjm");
        outf<<SecondKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_ThirdKey.zsjm");
        outf<<ThirdKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Weapons.zsjm");
        outf<<Weapons;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Armor.zsjm");
        outf<<Armor;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_GOLD.zsjm");
        outf<<GOLD;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_gk.zsjm");
        outf<<2;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_tj.zsjm");
        outf<<tj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_jj.zsjm");
        outf<<jj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_sj.zsjm");
        outf<<sj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_td.zsjm");
        outf<<td;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_jd.zsjm");
        outf<<jd;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_sd.zsjm");
        outf<<sd;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_qt.zsjm");
        for(int ru=1; ru<=qt_tot; ru++)
          outf<<qt[ru]<<'\n';
        outf.close();
        return 0;
      }
      else if(c==80 && x+1==33 && y==41 && Map[33][41]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,++x,"&");
        Map[x][y]=' ';
        GAMEOVER='?';
        HP=0;
      }
      else if(c==72 && x-1==32 && y==34 && Map[32][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Cmd.Cout(110,29,"��ȥɨ");
        Cmd.Cout(110,30,"��QWQ!");
        Cmd.Cout(113,31," ");
        Cmd.Cout(51,17,"(");
        Map[x][y]=' ';
        Map[31][113]=' ';
        Map[30][110]='#';
        Map[17][51]='(';
      }
      else if(c==72 && x-1==21 && y==39 && Map[21][39]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=15000;
        bz++;
      }
      else if(c==72 && x-1==21 && y==45 && Map[21][45]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=15000;
        bz++;
      }
      else if(c==72 && x-1==21 && y==75 && Map[21][75]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=15000;
        bz++;
      }
      else if(c==72 && x-1==21 && y==81 && Map[21][81]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=15000;
        bz++;
      }
      else if(bz==4&&bzcs==0)
      {
        Cmd.Cout(58,27,"    ");
        Map[27][48]=' ',Map[27][49]=' ',Map[27][50]=' ',Map[27][51]=' ',Map[27][52]=' ';
        Map[27][53]=' ',Map[27][54]=' ',Map[27][55]=' ',Map[27][56]=' ',Map[27][57]=' ';
        Map[27][62]=' ',Map[27][63]=' ',Map[27][64]=' ',Map[27][65]=' ',Map[27][66]=' ';
        Map[27][67]=' ',Map[27][68]=' ',Map[27][69]=' ',Map[27][70]=' ',Map[27][71]=' ';
        Map[28][81]=' ';
        Cmd.Cout(81,28," ");
        bzcs++;
      }
      else if(c==72 && x-1==26 && y==34 && Map[26][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=30000;
      }
      else if(c==72 && x-1==24 && y==34 && Map[24][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP-=10000;
      }
      else if(c==72 && x-1==22 && y==34 && Map[22][34]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[x][y]=' ';
        HP+=30000;
      }
      else if(c==72 && x-1==30 && y==110 && Map[30][110]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[30][110]=' ';
        ofstream outf;
        outf.open("D:\\mysterious_Palace\\game_archive\\system_X.zsjm");
        outf<<x;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Y.zsjm");
        outf<<y;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_HP.zsjm");
        outf<<HP;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_ATK.zsjm");
        outf<<ATK;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_DEF.zsjm");
        outf<<DEF;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_FirstKey.zsjm");
        outf<<FirstKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_SecondKey.zsjm");
        outf<<SecondKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_ThirdKey.zsjm");
        outf<<ThirdKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Weapons.zsjm");
        outf<<Weapons;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Armor.zsjm");
        outf<<Armor;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_GOLD.zsjm");
        outf<<GOLD;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_tj.zsjm");
        outf<<tj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_jj.zsjm");
        outf<<jj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_sj.zsjm");
        outf<<sj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_td.zsjm");
        outf<<td;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_jd.zsjm");
        outf<<jd;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_sd.zsjm");
        outf<<sd;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_qt.zsjm");
        for(int ru=1; ru<=qt_tot; ru++)
          outf<<qt[ru]<<'\n';
        outf.close();
      }
      else if(c==72 && x-1==34 && y==75 && Map[34][75]=='?')
      {
        Cmd.Cout(y,x," ");
        Cmd.Cout(y,--x,"&");
        Map[34][75]=' ';
        ofstream outf;
        outf.open("D:\\mysterious_Palace\\game_archive\\system_X.zsjm");
        outf<<x;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Y.zsjm");
        outf<<y;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_HP.zsjm");
        outf<<HP;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_ATK.zsjm");
        outf<<ATK;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_DEF.zsjm");
        outf<<DEF;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_FirstKey.zsjm");
        outf<<FirstKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_SecondKey.zsjm");
        outf<<SecondKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_ThirdKey.zsjm");
        outf<<ThirdKey;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Weapons.zsjm");
        outf<<Weapons;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_Armor.zsjm");
        outf<<Armor;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_GOLD.zsjm");
        outf<<GOLD;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_tj.zsjm");
        outf<<tj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_jj.zsjm");
        outf<<jj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_sj.zsjm");
        outf<<sj;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_td.zsjm");
        outf<<td;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_jd.zsjm");
        outf<<jd;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_sd.zsjm");
        outf<<sd;
        outf.close();
        outf.open("D:\\mysterious_Palace\\game_archive\\system_qt.zsjm");
        for(int ru=1; ru<=qt_tot; ru++)
          outf<<qt[ru]<<'\n';
        outf.close();
      }
      else
        d=-1;
      if(HP<=0)
      {
        Cmd.Clear();
        Cmd.TextColor(2,0);
        for(int i=0; i<43; i++)
        {
          for(int j=0; j<61; j++)
            cout<<"��";
          cout<<"\n";
        }
        Cmd.TextColor(12,0);
        Cmd.Cout(56,21,"GAMEOVER");
        Cmd.TextColor(7,0);
        if(GAMEOVER=='?')
          Cmd.Cout(80,30,"�㱻 ���� �ɵ��� ^_^");
        if(GAMEOVER=='a')
          Cmd.Cout(80,30,"�㱻 ����a ɱ���� ��");
        if(GAMEOVER=='b')
          Cmd.Cout(80,30,"�㱻 ����b ɱ���� ��");
        if(GAMEOVER=='c')
          Cmd.Cout(80,30,"�㱻 ����c ɱ���� ��");
        if(GAMEOVER=='d')
          Cmd.Cout(80,30,"�㱻 ����d ɱ���� ��");
        if(GAMEOVER=='e')
          Cmd.Cout(80,30,"�㱻 ����e ɱ���� ��");
        if(GAMEOVER=='A')
          Cmd.Cout(80,30,"�㱻 ����A ɱ���� ��");
        if(GAMEOVER=='B')
          Cmd.Cout(80,30,"�㱻 ����B ɱ���� ��");
        if(GAMEOVER=='C')
          Cmd.Cout(80,30,"�㱻 ����C ɱ���� ��");
        if(GAMEOVER=='D')
          Cmd.Cout(80,30,"�㱻 ����D ɱ���� ��");
        if(GAMEOVER=='E')
          Cmd.Cout(80,30,"�㱻 ����E ɱ���� ��");
        if(GAMEOVER=='2')
          Cmd.Cout(80,35,"�㱻 �Լ����츳�����ж� ɱ���� ��");
        if(GAMEOVER=='0')
        {
          Cmd.Cout(76,34,"    �㱻 ����֮ǽ ɱ���� ��  ");
          Cmd.Cout(76,35,"����,��ȷ��·��Ҫ���Լ�̽�� !");
        }
        if(GAMEOVER=='M')
        {
          Cmd.Cout(76,34,"    �㱻 BOOS ɱ���� ��  ");
          Cmd.Cout(76,35,"����,��Ҫ����,����������!");
        }
        Cmd.HideCursor();
        return 0;
      }
    }
  }
}
