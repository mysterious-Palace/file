#include <bits/stdc++.h>
#include <Pen.h>
#include <MATH0.h>
#include <LoadModel.h>
#include <Model.h>
#include <sound.h>
#include <win.h>
#include <ctime>
#include <pthread.h>
#define Seed() srand((unsigned)time(NULL))
#define Sound sound
#define Beep beep
#define IntToString inttostr
#define FloatToString ftostr
#define CharToString chartostring

window Win; 
pen Pen; 
LoadModel File;
MATH Math;
model Model;
speech Speech;
cmd Cmd;

